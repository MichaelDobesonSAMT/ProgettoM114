﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cifratura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer1.Enabled = true;
            button1.BackColor = Color.LightGreen;
            dataGridView1.Visible = false;
            dataGridView1.RowCount = 5;
            dataGridView1.ColumnCount = 5;
            dataGridView1.Enabled = false;
        }
        int cipherChoice = 0;

        private void timer1_Tick(object sender, EventArgs e)
        {
            string res = "";
            string input = textBox1.Text;
            string key = textBox2.Text;
            string[,] gridKey;
            switch (cipherChoice)
            {
                case 0:
                    res = caesarCipher(input, key);
                    break;
                case 1:
                    res = atbahCipher(input);
                    break;
                case 2:
                    res = atbashCipher(input);
                    break;
                case 3:
                    res = albamCipher(input);
                    break;
                case 4:
                    gridKey = assignGridValues();
                    res = polibioCipher(input, gridKey);
                    break;
            }
            textBox3.Text = res;
        }

        // Caesar Cipher
        public int romanValue(char r)
        {
            if (r == 'I')
                return 1;
            if (r == 'V')
                return 5;
            if (r == 'X')
                return 10;
            if (r == 'L')
                return 50;
            if (r == 'C')
                return 100;
            if (r == 'D')
                return 500;
            if (r == 'M')
                return 1000;
            return -1;
        }

        public int romanToInt(string str)
        {
            int num = 0;

            for (int i = 0; i < str.Length; i++)
            {
                int s1 = romanValue(str[i]);

                if (s1 == -1)
                {
                    return -1;
                }

                if (i + 1 < str.Length)
                {
                    int s2 = romanValue(str[i + 1]);

                    if (s2 == -1)
                    {
                        return -1;
                    }

                    if (s1 >= s2)
                    {
                        num = num + s1;
                    }
                    else
                    {
                        num = num + s2 - s1;
                        i++;
                    }
                }
                else
                {
                    num = num + s1;
                    i++;
                }
            }

            return num;
        }

        public char romanValue(int n)
        {
            if (n >= 1000)
                return 'M';
            if (n >= 500)
                return 'D';
            if (n >= 100)
                return 'C';
            if (n >= 50)
                return 'L';
            if (n >= 10)
                return 'X';
            if (n >= 5)
                return 'V';
            if (n >= 1)
                return 'I';
            return ' ';
        }

        public string intToRoman(int num)
        {
            int n = num;
            string str = "";
            while (n > 0)
            {
                char c = romanValue(n);
                str += c;
                n -= romanValue(c);
            }
            return str;
        }

        public string caesarCipher(string sOld, string rom)
        {
            int num = romanToInt(rom);
            if (num != -1)
            {
                string sNew = "";
                for(int i = 0; i < sOld.Length; i++)
                {
                    if(sOld[i] >= 'a' && sOld[i] <= 'z')
                    {
                        num = romanToInt(rom);
                        while (sOld[i] + num > 'z')
                        {
                            num -= 26;
                        }
                        sNew += Convert.ToChar((sOld[i] + num));
                    }
                    else if (sOld[i] >= 'A' && sOld[i] <= 'Z')
                    {
                        while (sOld[i] + num > 'Z')
                        {
                            num -= 26;
                        }
                        sNew += Convert.ToChar((sOld[i] + num));
                    }
                    /*else if (sOld[i] >= '0' && sOld[i] <= '9')
                    {
                        int k = 1;
                        string strN = Convert.ToString(sOld[i]);
                        while (sOld[i+k] >= '0' && sOld[i+k] <= '9' && sOld.Length > (i+k))
                        {
                            k++;
                            strN += sOld[i + k];
                        }

                        sNew += intToRoman(Convert.ToInt32(strN));
                    }*/
                    else
                    {
                        sNew += sOld[i];
                    }
                }
                return sNew;
            }
            else
            {
                return "Invalid Roman Numeral";
            }
        }

        // Atbah cipher
        public string atbahCipher(string sOld)
        {
            string sNew = "";
            for(int i = 0; i < sOld.Length; i++)
            {
                if (sOld[i] >= 'a' && sOld[i] <= 'z' || sOld[i] >= 'A' && sOld[i] <= 'Z')
                {
                    int capital = 0;
                    if (sOld[i] >= 'A' && sOld[i] <= 'Z')
                    {
                        capital = 32;
                    }

                    int num = 0;
                    if (sOld[i] >= 'a' && sOld[i] <= 'i' || sOld[i] >= 'A' && sOld[i] <= 'I')
                    {
                        num = 10 - (sOld[i] - ('a' - capital) + 2);
                    }
                    else if (sOld[i] >= 'j' && sOld[i] <= 'r' || sOld[i] >= 'J' && sOld[i] <= 'R')
                    {
                        num = 28 - (sOld[i] - ('a' - capital) + 2);
                    }else if (sOld[i] >= 's' && sOld[i] <= 'z' || sOld[i] >= 'S' && sOld[i] <= 'Z')
                    {
                        num = 45 - (sOld[i] - ('a' - capital) + 2);
                    }

                    if (sOld[i] == 'n' || sOld[i] == 'N')
                    {
                        sNew += Convert.ToChar('e' - capital);
                    }
                    else if(sOld[i] == 'e' || sOld[i] == 'E')
                    {
                        sNew += Convert.ToChar('n' - capital);
                    }
                    else
                    {
                        sNew += Convert.ToChar(('a' - capital) + num);
                    }
                }
                else
                {
                    sNew += sOld[i];
                }
            }
            return sNew;
        }

        // atbash
        public string atbashCipher(string sOld)
        {
            string sNew = "";
            for (int i = 0; i < sOld.Length; i++)
            {
                if (sOld[i] >= 'a' && sOld[i] <= 'z' || sOld[i] >= 'A' && sOld[i] <= 'Z')
                {
                    int capital = 0;
                    if (sOld[i] >= 'A' && sOld[i] <= 'Z')
                    {
                        capital = 32;
                    }

                    int num = 27 - (sOld[i] - ('a' - capital) + 2);
                    sNew += Convert.ToChar(('a' - capital) + num);
                }
                else
                {
                    sNew += sOld[i];
                }
            }
            return sNew;
        }

        // albam
        public string albamCipher(string sOld)
        {
            string sNew = "";
            for (int i = 0; i < sOld.Length; i++)
            {
                if (sOld[i] >= 'a' && sOld[i] <= 'z' || sOld[i] >= 'A' && sOld[i] <= 'Z')
                {
                    int capital = 0;
                    if (sOld[i] >= 'A' && sOld[i] <= 'Z')
                    {
                        capital = 32;
                    }

                    int num = 0;
                    if(sOld[i] >= 'a' && sOld[i] <= 'm' || sOld[i] >= 'A' && sOld[i] <= 'M')
                    {
                        num = (15 + ((sOld[i] - ('a' - capital)) * 2)) - (sOld[i] - ('a' - capital) + 2);
                    }
                    else
                    {
                        num = (15 + ((sOld[i] - ('n' - capital)) * 2)) - (sOld[i] - ('a' - capital) + 2);
                    }
                    sNew += Convert.ToChar(('a' - capital) + num);
                }
                else
                {
                    sNew += sOld[i];
                }
            }
            return sNew;
        }

        // polibio
        private string[,] assignGridValues()
        {
            string[,] grid = new string[5,5];
            int k = 0;
            for (int i = 0; i < grid.GetLength(0); i++)
            {
                for (int j = 0; j < grid.GetLength(1); j++)
                {
                    grid[i, j] = Convert.ToString(Convert.ToChar('A' + k));
                    if(grid[i, j] == "I")
                    {
                        grid[i, j] += ",J";
                        k++;
                    }
                    dataGridView1.Rows[i].Cells[j].Value = grid[i, j];
                    k++;
                }
            }

            return grid;
        }
        public string polibioCipher(string sOld, string[,] grid)
        {
            string sNew = "";
            for (int k = 0; k < sOld.Length; k++)
            {
                char cOld = Convert.ToChar(sOld[k]);
                if (cOld >= 'a' && cOld <= 'z')
                {
                    cOld = Convert.ToChar(sOld[k] - 32);
                }

                if (cOld >= 'A' && cOld <= 'Z')
                {
                    
                    for (int i = 0; i < grid.GetLength(0); i++)
                    {
                        for (int j = 0; j < grid.GetLength(1); j++)
                        {
                            if (grid[i, j].Contains(cOld))
                            {
                                sNew += (i+1) + "" + (j+1) + " ";
                            }
                        }
                    }
                }
                else
                {
                    sNew += sOld[k];
                }
            }
            return sNew;
        }

        // monoalphabetic cipher
        public bool checkKey(string key)
        {
            if (key.Length >= 26 && key.ToUpper().Distinct().Count() == key.Length && Regex.IsMatch(key, @"^[a-zA-Z]+$"))
            {
                return true;
            }
            return false;
        }
        public string monoalphabeticCipher(string sOld, string key)
        {
            int num = 0;
            string sNew = "";
            // work in progress
            for (int i = 0; i < sOld.Length; i++)
            {
                if (sOld[i] >= 'a' && sOld[i] <= 'z')
                {
                    num = 0;
                    while (sOld[i] + num > 'z')
                    {
                        num -= 26;
                    }
                    sNew += Convert.ToChar((sOld[i] + num));
                }
                else if (sOld[i] >= 'A' && sOld[i] <= 'Z')
                {
                    while (sOld[i] + num > 'Z')
                    {
                        num -= 26;
                    }
                    sNew += Convert.ToChar((sOld[i] + num));
                }
                else
                {
                    sNew += sOld[i];
                }
            }
            return sNew;
        }

        public void resetClick()
        {
            button1.BackColor = default;
            button3.BackColor = default;
            button4.BackColor = default;
            button5.BackColor = default;
            button6.BackColor = default;
            textBox2.Visible = false;
            dataGridView1.Visible = false;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cipherChoice = 0;
            resetClick();
            textBox2.Visible = true;
            button1.BackColor = Color.LightGreen;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cipherChoice = 1;
            resetClick();
            button3.BackColor = Color.LightGreen;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            cipherChoice = 2;
            resetClick();
            button4.BackColor = Color.LightGreen;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            cipherChoice = 3;
            resetClick();
            button5.BackColor = Color.LightGreen;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            cipherChoice = 4;
            resetClick();
            dataGridView1.Visible = true;
            button6.BackColor = Color.LightGreen;
        }
    }
}
